package medilux.senisionProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SenisionProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SenisionProjectApplication.class, args);
	}

}
