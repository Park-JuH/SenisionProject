package medilux.senisionProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SenisionProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
